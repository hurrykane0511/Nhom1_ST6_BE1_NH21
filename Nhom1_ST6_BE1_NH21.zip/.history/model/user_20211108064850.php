<?php

class User extends Db
{
}
